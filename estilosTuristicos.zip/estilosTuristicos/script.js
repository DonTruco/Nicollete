 const destinos = [
    'Machu Pichu, Lugar histórico en Peru',
    'Dubái, Emiratos Árabes Unidos',
    'Valle del cocoro, Colombia',
    'Hawai, Estado de EE. UU.',
    'Taj Mahal, India' ,
    'Bangkok, Tailandia'

 ]

document.getElementById('button-random').addEventListener('click', function(){
    const randomText = Math.floor(Math.random() * destinos.length);
    document.getElementById('texto-random').textContent = destinos[randomText]
})

/* Math.floor para redondear a numero entero*/


// Función para establecer una cookie

function setCookie(name, value, days) {
    //crear el objeto usando constructor de clase DATE
    const d = new Date();
    //calcula la fecha de expiracion
    d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
    //crea una variable que combierte a string 
    const expires = "expires=" + d.toUTCString();
    document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

// Función para obtener una cookie
function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

// Función para comprobar la aceptación de cookies
function checkCookie() {
    let cookieConsent = getCookie("cookieConsent");
    if (cookieConsent !== "accepted") {
        // Mostrar banner de cookies
        let banner = document.createElement("div");
        banner.innerHTML = '<p>Este sitio usa cookies. <button id="acceptCookies">Aceptar</button></p>';
        document.body.appendChild(banner);

        document.getElementById("acceptCookies").onclick = function () {
            setCookie("cookieConsent", "accepted", 30); // Expira en 30 días
            banner.style.display = "none";
        };
    }
}

// Ejecutar la función al cargar la página
checkCookie();
